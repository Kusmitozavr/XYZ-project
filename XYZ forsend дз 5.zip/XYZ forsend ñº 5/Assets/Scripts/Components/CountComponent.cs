﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace PixelCrew
{
    public class CountComponent : MonoBehaviour
    {
        public float wallet = 0;

        public void CheckWalletSilver()
        {
            wallet = wallet + 1;
            Debug.Log(wallet);
        }

        public void CheckWalletGold()
        {
            wallet = wallet + 10;
            Debug.Log(wallet);
        }
    }
}