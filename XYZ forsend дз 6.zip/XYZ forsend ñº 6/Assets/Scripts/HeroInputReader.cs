using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Scripts
{
    public class HeroInputReader : MonoBehaviour
{
    [SerializeField] private Hero _hero;

    private HeroInputAction _inputActions;

    private void Awake()
    {
      _inputActions = new HeroInputAction();
      _inputActions.Hero.HorizjntalMovement.performed += OnHorizontalMovement;
      _inputActions.Hero.HorizjntalMovement.canceled += OnHorizontalMovement;

      _inputActions.Hero.Interact.canceled += OnInteract;


      _inputActions.Hero.SaySomething.performed += OnSaySomething;
    }

    private void OnEnable()
    {
      _inputActions.Enable();
    }

    public void OnHorizontalMovement(InputAction.CallbackContext context)
    {
      var direction = context.ReadValue<Vector2>();
      _hero.SetDirection(direction);
    }

    public void OnSaySomething(InputAction.CallbackContext context)
    {
      if (context.canceled)
      {   
        _hero.SaySomething();
      }
    }
    public void OnInteract(InputAction.CallbackContext context)
    {
      if (context.canceled)
      {   
        _hero.Interact();
      }
    }
}
}