using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.InputSystem;
using Scripts.Component;

namespace Scripts
{
    public class Hero : MonoBehaviour
{
    private Rigidbody2D _rigidbody;
    private Vector2 _direction;
    private Animator _animator;
    private SpriteRenderer _sprite;
    private bool _isGround;
    private bool _allowDoubleJump;
    private Collider2D[] _interactionResult = new Collider2D[1];

    private static readonly int IsGroundedKey = Animator.StringToHash("IsGrounded");
    private static readonly int IsRunningKey = Animator.StringToHash("IsRunning");
    private static readonly int VerticalVelocityKey = Animator.StringToHash("VerticalVelocity");
    private static readonly int Hit = Animator.StringToHash("hit");

    [SerializeField]private float _speed;
    [SerializeField]private float _jumpspeed;
    [SerializeField]private float _damagejumpspeed;
    [SerializeField]private float _interactradius;
    [SerializeField]private LayerMask _interactionLayer;

    [SerializeField]private LayerCheck _groundCheck;

    private void Awake()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        _animator = GetComponent<Animator>();
        _sprite = GetComponent<SpriteRenderer>();
    }

    public void SetDirection(Vector2 direction)
    {
        _direction = direction;
    }

    private void Update()
    {
          _isGround = IsGround();
    }

    private void FixedUpdate()
    {
        var xVelocity = _direction.x * _speed;
        var yVelocity = CalculateYVelocity();
        _rigidbody.velocity = new Vector2(xVelocity, yVelocity);

        _animator.SetBool(IsGroundedKey, _isGround);
        _animator.SetFloat(VerticalVelocityKey , _rigidbody.velocity.y);
        _animator.SetBool(IsRunningKey, _direction.x != 0);

        UpdateSpriteDirection();
    }

    private float CalculateYVelocity()
    {
        var yVelocity = _rigidbody.velocity.y;
        var isJumpPressing = _direction.y > 0;

        if (_isGround) _allowDoubleJump = true;
        if(isJumpPressing)
        {
            yVelocity = CalculateJumpVelocity(yVelocity);
            if (_isGround && _rigidbody.velocity.y <= 0.001f)
            {
                 _rigidbody.AddForce(Vector2.up * _jumpspeed, ForceMode2D.Impulse);
            }
        }   else if (_rigidbody.velocity.y > 0)
        {
            yVelocity *= 0.5f;
            _rigidbody.velocity = new Vector2(_rigidbody.velocity.x, yVelocity);
        }

        return yVelocity;
    }

    private float CalculateJumpVelocity(float yVelocity)
    {
        var isFalling = _rigidbody.velocity.y <= 0.001f;
        if (!isFalling) return yVelocity;

        if(_isGround)
        {
            yVelocity += _jumpspeed;
        } else if (_allowDoubleJump)
        {
            yVelocity += _jumpspeed;
            _allowDoubleJump = false;
        }

        return yVelocity;
    }

    private void UpdateSpriteDirection()
    {
        if (_direction.x > 0)
        {
            _sprite.flipX = false;
        } else if(_direction.x < 0)
        {
            _sprite.flipX = true;
        }
    }

    private bool IsGround()
    {
        return _groundCheck.IsTouchingplayer;
    }
    
    public void SaySomething()
    {
        Debug.Log("Hello!");
    }

    public void TaleDamage()
    {
        _animator.SetTrigger(Hit);
        _rigidbody.velocity = new Vector2(_rigidbody.velocity.x, _damagejumpspeed);
    }

    public void Interact()
    {
        var size = Physics2D.OverlapCircleNonAlloc(transform.position, _interactradius, _interactionResult, _interactionLayer);

        for(int i = 0; i < size; i++)
        {
            var interactable = _interactionResult[i].GetComponent<InteractableComponent>();
            if (interactable != null)
            {
                interactable.Interact();
            }
        }
    }
}
}